# Builtin Notebook Output Renderers for Visual Studio Code

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

## Features

This extension provides the following notebook renderers for VS Code:

- Image renderer for png, jpeg and gif
